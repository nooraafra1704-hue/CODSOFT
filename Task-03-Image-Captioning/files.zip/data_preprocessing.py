"""
data_preprocessing.py
======================
Handles loading and cleaning the Flickr8k-style captions file, building a
vocabulary with TextVectorization, and constructing a tf.data pipeline that
yields (image_features, decoder_input_tokens) -> target_tokens pairs for
teacher-forced training.

Expected captions file format (Flickr8k "captions.txt" from Kaggle):
    image,caption
    1000268201_693b08cb0e.jpg,A child in a pink dress is climbing up a set of stairs .
    1000268201_693b08cb0e.jpg,A girl going into a wooden building .
    ...
"""

import re
import json
import pickle
from collections import defaultdict

import numpy as np
import tensorflow as tf

import config


def load_captions(captions_file):
    """Parses the captions file into {image_filename: [caption1, caption2, ...]}."""
    mapping = defaultdict(list)
    with open(captions_file, "r", encoding="utf-8") as f:
        next(f)  # skip header line "image,caption"
        for line in f:
            line = line.strip()
            if not line or "," not in line:
                continue
            image_id, caption = line.split(",", 1)
            mapping[image_id.strip()].append(caption.strip())
    return mapping


def clean_caption(caption):
    """Lowercases, strips punctuation/digits, and wraps with start/end tokens."""
    caption = caption.lower()
    caption = re.sub(r"[^a-z\s]", "", caption)
    caption = re.sub(r"\s+", " ", caption).strip()
    return f"{config.START_TOKEN} {caption} {config.END_TOKEN}"


def clean_all_captions(mapping):
    """Applies clean_caption() to every caption in the mapping (in place-safe copy)."""
    cleaned = {}
    for image_id, captions in mapping.items():
        cleaned[image_id] = [clean_caption(c) for c in captions]
    return cleaned


def build_vectorizer(all_captions):
    """Fits a TextVectorization layer on every cleaned caption in the dataset."""
    vectorizer = tf.keras.layers.TextVectorization(
        max_tokens=config.VOCAB_SIZE,
        output_mode="int",
        output_sequence_length=config.MAX_CAPTION_LEN,
        standardize=None,  # captions are already cleaned
    )
    vectorizer.adapt(all_captions)
    return vectorizer


def save_vectorizer_vocab(vectorizer, path=config.TOKENIZER_FILE):
    vocab = vectorizer.get_vocabulary()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(vocab, f)


def load_vectorizer_vocab(path=config.TOKENIZER_FILE):
    with open(path, "r", encoding="utf-8") as f:
        vocab = json.load(f)
    vectorizer = tf.keras.layers.TextVectorization(
        max_tokens=config.VOCAB_SIZE,
        output_mode="int",
        output_sequence_length=config.MAX_CAPTION_LEN,
        standardize=None,
        vocabulary=vocab,
    )
    return vectorizer


def build_dataset(features, captions_mapping, vectorizer, batch_size=config.BATCH_SIZE):
    """Builds a tf.data.Dataset of ((image_features, decoder_input), target).

    - decoder_input: caption tokens shifted right, e.g. [<start>, a, dog, ...]
    - target:        caption tokens shifted left,  e.g. [a, dog, ..., <end>]
    This is standard teacher forcing for sequence generation.
    """
    image_feature_list = []
    input_seq_list = []
    target_seq_list = []

    for image_id, captions in captions_mapping.items():
        if image_id not in features:
            continue
        feat = features[image_id]
        for caption in captions:
            tokens = vectorizer([caption])[0].numpy()
            input_seq_list.append(tokens[:-1])
            target_seq_list.append(tokens[1:])
            image_feature_list.append(feat)

    image_feature_arr = np.array(image_feature_list, dtype=np.float32)
    input_seq_arr = np.array(input_seq_list, dtype=np.int32)
    target_seq_arr = np.array(target_seq_list, dtype=np.int32)

    dataset = tf.data.Dataset.from_tensor_slices(
        ((image_feature_arr, input_seq_arr), target_seq_arr)
    )
    dataset = dataset.shuffle(config.SHUFFLE_BUFFER).batch(batch_size)
    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset


def train_val_split(captions_mapping, val_ratio=0.1, seed=42):
    """Splits image ids into train/val sets (split by image, not by caption,
    so the same image's captions never leak across the split)."""
    image_ids = list(captions_mapping.keys())
    rng = np.random.default_rng(seed)
    rng.shuffle(image_ids)
    split_idx = int(len(image_ids) * (1 - val_ratio))
    train_ids, val_ids = image_ids[:split_idx], image_ids[split_idx:]

    train_map = {k: captions_mapping[k] for k in train_ids}
    val_map = {k: captions_mapping[k] for k in val_ids}
    return train_map, val_map
