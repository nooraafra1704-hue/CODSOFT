"""
Configuration and hyperparameters for the Image Captioning project.
"""

# ---------- Image / CNN settings ----------
IMAGE_SIZE = (224, 224)          # Required input size for VGG16
CNN_FEATURE_SHAPE = (49, 512)    # VGG16 block5_pool reshaped: 7x7 spatial grid, 512 channels

# ---------- Text / vocabulary settings ----------
VOCAB_SIZE = 10000                # Max vocabulary size for the tokenizer
MAX_CAPTION_LEN = 40               # Max tokens per caption (including <start>/<end>)
START_TOKEN = "<start>"
END_TOKEN = "<end>"

# ---------- Transformer decoder settings ----------
EMBED_DIM = 512                   # Embedding / model dimension (d_model)
FF_DIM = 1024                     # Feed-forward hidden dimension
NUM_HEADS = 8                     # Attention heads
NUM_DECODER_LAYERS = 2            # Stacked transformer decoder blocks
DROPOUT_RATE = 0.1

# ---------- Training settings ----------
BATCH_SIZE = 64
EPOCHS = 30
LEARNING_RATE = 1e-4
SHUFFLE_BUFFER = 1000

# ---------- File paths (adjust to your local dataset location) ----------
DATASET_DIR = "dataset"
IMAGES_DIR = f"{DATASET_DIR}/Images"
CAPTIONS_FILE = f"{DATASET_DIR}/captions.txt"     # Flickr8k captions file
FEATURES_FILE = "features.pkl"                    # Cached VGG16 features
TOKENIZER_FILE = "tokenizer_vocab.json"            # Saved vocabulary
CHECKPOINT_DIR = "checkpoints"
