"""
generate_caption.py
=====================
Loads a trained model and generates a caption for a new image using
greedy decoding (predict one token at a time, always picking the
highest-probability next word, until <end> or MAX_CAPTION_LEN is reached).

Usage:
    python generate_caption.py --image path/to/image.jpg
"""

import argparse

import numpy as np
import tensorflow as tf

import config
import data_preprocessing as dp
from feature_extractor import build_cnn_encoder, load_and_preprocess_image
from transformer_model import ImageCaptioningTransformer


def generate_caption(model, vectorizer, image_features, max_len=config.MAX_CAPTION_LEN):
    vocab = vectorizer.get_vocabulary()
    word_to_index = {word: idx for idx, word in enumerate(vocab)}
    index_to_word = {idx: word for idx, word in enumerate(vocab)}

    start_id = word_to_index[config.START_TOKEN]
    end_id = word_to_index[config.END_TOKEN]

    # image_features: (49, 512) -> add batch dimension
    image_features = np.expand_dims(image_features, axis=0)

    generated_ids = [start_id]

    for _ in range(max_len - 1):
        input_seq = generated_ids + [0] * (max_len - 1 - len(generated_ids))
        input_seq = np.array([input_seq[: max_len - 1]], dtype=np.int32)

        predictions = model((image_features, input_seq), training=False)
        next_token_logits = predictions[0, len(generated_ids) - 1, :]
        next_id = int(tf.argmax(next_token_logits).numpy())

        if next_id == end_id:
            break
        generated_ids.append(next_id)

    words = [index_to_word.get(idx, "[UNK]") for idx in generated_ids[1:]]  # skip <start>
    return " ".join(words)


def main():
    parser = argparse.ArgumentParser(description="Generate a caption for an image.")
    parser.add_argument("--image", type=str, required=True, help="Path to the input image")
    args = parser.parse_args()

    print("Loading vocabulary...")
    vectorizer = dp.load_vectorizer_vocab(config.TOKENIZER_FILE)
    vocab_size = len(vectorizer.get_vocabulary())

    print("Rebuilding model and loading trained weights...")
    model = ImageCaptioningTransformer(vocab_size=vocab_size)
    # Build the model by running a dummy forward pass before loading weights
    dummy_img = np.zeros((1, *config.CNN_FEATURE_SHAPE), dtype=np.float32)
    dummy_seq = np.zeros((1, config.MAX_CAPTION_LEN - 1), dtype=np.int32)
    model((dummy_img, dummy_seq))
    model.load_weights(f"{config.CHECKPOINT_DIR}/final_model.weights.h5")

    print("Extracting image features with VGG16...")
    cnn_encoder = build_cnn_encoder()
    image_array = load_and_preprocess_image(args.image)
    image_features = cnn_encoder.predict(np.expand_dims(image_array, axis=0), verbose=0)[0]

    print("Generating caption...")
    caption = generate_caption(model, vectorizer, image_features)
    print("\nPredicted caption:")
    print(f"  {caption}")


if __name__ == "__main__":
    main()
