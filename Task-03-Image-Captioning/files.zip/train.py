"""
train.py
=========
Trains the Transformer image captioning model.

Usage:
    1. Make sure you've run feature_extractor.py first to cache VGG16
       features for all training images.
    2. Run: python train.py

This script:
    - Loads captions and cleans them
    - Builds (or loads) the vocabulary
    - Loads cached VGG16 features
    - Splits data into train/validation sets
    - Builds tf.data pipelines
    - Trains the Transformer decoder
    - Saves the trained weights and vocabulary for later inference
"""

import os
import pickle

import tensorflow as tf

import config
import data_preprocessing as dp
from transformer_model import ImageCaptioningTransformer, masked_loss, masked_accuracy


def main():
    print("Loading captions...")
    raw_captions = dp.load_captions(config.CAPTIONS_FILE)
    cleaned_captions = dp.clean_all_captions(raw_captions)

    print("Loading cached VGG16 features...")
    with open(config.FEATURES_FILE, "rb") as f:
        features = pickle.load(f)

    # Keep only images that actually have cached features
    cleaned_captions = {k: v for k, v in cleaned_captions.items() if k in features}
    print(f"Usable images: {len(cleaned_captions)}")

    print("Building vocabulary...")
    all_captions_flat = [c for caps in cleaned_captions.values() for c in caps]
    vectorizer = dp.build_vectorizer(all_captions_flat)
    dp.save_vectorizer_vocab(vectorizer, config.TOKENIZER_FILE)
    vocab_size = len(vectorizer.get_vocabulary())
    print(f"Vocabulary size: {vocab_size}")

    print("Splitting train/validation sets...")
    train_captions, val_captions = dp.train_val_split(cleaned_captions, val_ratio=0.1)

    print("Building tf.data pipelines...")
    train_ds = dp.build_dataset(features, train_captions, vectorizer, config.BATCH_SIZE)
    val_ds = dp.build_dataset(features, val_captions, vectorizer, config.BATCH_SIZE)

    print("Building model...")
    model = ImageCaptioningTransformer(vocab_size=vocab_size)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(config.LEARNING_RATE),
        loss=masked_loss,
        metrics=[masked_accuracy],
    )

    os.makedirs(config.CHECKPOINT_DIR, exist_ok=True)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(
            filepath=os.path.join(config.CHECKPOINT_DIR, "model.weights.h5"),
            save_weights_only=True,
            save_best_only=True,
            monitor="val_loss",
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=5, restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=2
        ),
    ]

    print("Starting training...")
    model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=config.EPOCHS,
        callbacks=callbacks,
    )

    model.save_weights(os.path.join(config.CHECKPOINT_DIR, "final_model.weights.h5"))
    print("Training complete. Weights saved to the checkpoints/ directory.")


if __name__ == "__main__":
    main()
