"""
feature_extractor.py
=====================
Uses a pre-trained VGG16 (ImageNet weights) as a frozen CNN encoder to turn
each image into a sequence of 49 visual tokens (7x7 spatial grid, 512
channels each). These tokens are later used as the "memory" that the
Transformer decoder cross-attends to when generating captions.
"""

import os
import pickle

import numpy as np
from tqdm import tqdm
import tensorflow as tf
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array

import config


def build_cnn_encoder():
    """Builds a frozen VGG16 feature extractor.

    Returns a Keras model that maps an image of shape (224, 224, 3) to a
    sequence of visual tokens of shape (49, 512) -- the output of the last
    convolutional block (block5_pool) reshaped from (7, 7, 512).
    """
    base_model = VGG16(include_top=False, weights="imagenet",
                        input_shape=(*config.IMAGE_SIZE, 3))
    base_model.trainable = False  # Freeze the CNN; we only train the decoder

    inputs = base_model.input
    feature_map = base_model.output                    # (7, 7, 512)
    flattened = tf.keras.layers.Reshape(
        config.CNN_FEATURE_SHAPE)(feature_map)          # (49, 512)

    return tf.keras.Model(inputs=inputs, outputs=flattened, name="vgg16_encoder")


def load_and_preprocess_image(image_path):
    """Loads an image from disk and prepares it for VGG16."""
    img = load_img(image_path, target_size=config.IMAGE_SIZE)
    array = img_to_array(img)
    array = preprocess_input(array)
    return array


def extract_features(images_dir, output_path=config.FEATURES_FILE, batch_size=32):
    """Extracts VGG16 features for every image in `images_dir` and caches
    them to a pickle file as {image_filename: np.ndarray(49, 512)}.
    """
    encoder = build_cnn_encoder()
    image_files = [f for f in os.listdir(images_dir)
                   if f.lower().endswith((".jpg", ".jpeg", ".png"))]

    features = {}
    for i in tqdm(range(0, len(image_files), batch_size), desc="Extracting features"):
        batch_files = image_files[i:i + batch_size]
        batch_images = np.stack(
            [load_and_preprocess_image(os.path.join(images_dir, f)) for f in batch_files]
        )
        batch_features = encoder.predict(batch_images, verbose=0)
        for fname, feat in zip(batch_files, batch_features):
            features[fname] = feat

    with open(output_path, "wb") as f:
        pickle.dump(features, f)

    print(f"Saved features for {len(features)} images to {output_path}")
    return features


if __name__ == "__main__":
    extract_features(config.IMAGES_DIR, config.FEATURES_FILE)
