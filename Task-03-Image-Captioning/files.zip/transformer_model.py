"""
transformer_model.py
======================
Transformer-based caption decoder. The frozen VGG16 encoder (see
feature_extractor.py) produces a sequence of 49 visual tokens per image.
This module defines a Transformer decoder that:
  1. Embeds caption tokens (+ positional encoding)
  2. Applies causal (masked) self-attention over the caption so far
  3. Applies cross-attention over the 49 visual tokens from VGG16
  4. Predicts the next token in the caption

This mirrors the standard "encoder-decoder" Transformer architecture, where
the CNN feature map plays the role of the encoder output.
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

import config


def get_positional_encoding(length, depth):
    """Standard sinusoidal positional encoding, as in 'Attention Is All You Need'."""
    depth_half = depth / 2
    positions = np.arange(length)[:, np.newaxis]
    depths = np.arange(depth_half)[np.newaxis, :] / depth_half

    angle_rates = 1 / (10000 ** depths)
    angle_rads = positions * angle_rates

    pos_encoding = np.concatenate([np.sin(angle_rads), np.cos(angle_rads)], axis=-1)
    return tf.cast(pos_encoding, dtype=tf.float32)


class CaptionEmbedding(layers.Layer):
    """Token embedding + fixed positional encoding for caption sequences."""

    def __init__(self, vocab_size, embed_dim, max_len, **kwargs):
        super().__init__(**kwargs)
        # Note: mask_zero is intentionally left off. Padding (token id 0) is
        # handled explicitly by masked_loss/masked_accuracy below instead of
        # relying on Keras's automatic mask propagation, which avoids a
        # shape conflict when combined with a custom loss during model.fit.
        self.token_embedding = layers.Embedding(
            input_dim=vocab_size, output_dim=embed_dim
        )
        self.pos_encoding = get_positional_encoding(max_len, embed_dim)
        self.embed_dim = embed_dim

    def call(self, tokens):
        seq_len = tf.shape(tokens)[1]
        x = self.token_embedding(tokens)
        x *= tf.math.sqrt(tf.cast(self.embed_dim, tf.float32))  # scale, as in the paper
        x = x + self.pos_encoding[tf.newaxis, :seq_len, :]
        return x


class TransformerDecoderBlock(layers.Layer):
    """One Transformer decoder block: masked self-attention, cross-attention
    over image features, and a feed-forward network, each with residual
    connections and layer normalization."""

    def __init__(self, embed_dim, num_heads, ff_dim, dropout_rate=0.1, **kwargs):
        super().__init__(**kwargs)
        self.self_attention = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim // num_heads, dropout=dropout_rate
        )
        self.cross_attention = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim // num_heads, dropout=dropout_rate
        )
        self.ffn = tf.keras.Sequential([
            layers.Dense(ff_dim, activation="relu"),
            layers.Dense(embed_dim),
        ])

        self.norm1 = layers.LayerNormalization(epsilon=1e-6)
        self.norm2 = layers.LayerNormalization(epsilon=1e-6)
        self.norm3 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout = layers.Dropout(dropout_rate)
        self.supports_masking = True

    def call(self, caption_seq, image_features, training=False, use_causal_mask=True):
        # 1. Masked self-attention over the caption generated so far
        attn1 = self.self_attention(
            query=caption_seq, value=caption_seq, key=caption_seq,
            use_causal_mask=use_causal_mask, training=training,
        )
        x = self.norm1(caption_seq + attn1)

        # 2. Cross-attention: caption tokens attend to the 49 visual tokens
        attn2 = self.cross_attention(
            query=x, value=image_features, key=image_features, training=training,
        )
        x = self.norm2(x + attn2)

        # 3. Feed-forward network
        ffn_out = self.ffn(x)
        ffn_out = self.dropout(ffn_out, training=training)
        x = self.norm3(x + ffn_out)
        return x


class ImageCaptioningTransformer(tf.keras.Model):
    """Full model: projects VGG16 features into the model's embedding space,
    then decodes a caption token-by-token using stacked decoder blocks."""

    def __init__(self, vocab_size, max_len=config.MAX_CAPTION_LEN,
                 embed_dim=config.EMBED_DIM, num_heads=config.NUM_HEADS,
                 ff_dim=config.FF_DIM, num_layers=config.NUM_DECODER_LAYERS,
                 dropout_rate=config.DROPOUT_RATE, **kwargs):
        super().__init__(**kwargs)

        # Projects the 512-dim VGG16 channel features into embed_dim
        self.image_projection = layers.Dense(embed_dim, activation="relu")

        self.caption_embedding = CaptionEmbedding(vocab_size, embed_dim, max_len)
        self.decoder_blocks = [
            TransformerDecoderBlock(embed_dim, num_heads, ff_dim, dropout_rate)
            for _ in range(num_layers)
        ]
        self.dropout = layers.Dropout(dropout_rate)
        self.output_layer = layers.Dense(vocab_size)

    def call(self, inputs, training=False):
        image_features, caption_tokens = inputs        # (B, 49, 512), (B, T)

        image_embed = self.image_projection(image_features)   # (B, 49, embed_dim)
        x = self.caption_embedding(caption_tokens)             # (B, T, embed_dim)
        x = self.dropout(x, training=training)

        for block in self.decoder_blocks:
            x = block(x, image_embed, training=training)

        logits = self.output_layer(x)                          # (B, T, vocab_size)
        return logits


def masked_loss(y_true, y_pred):
    """Sparse categorical cross-entropy that ignores padding (token id 0)."""
    loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(
        from_logits=True, reduction="none"
    )
    mask = tf.cast(y_true != 0, dtype=tf.float32)
    loss = loss_fn(y_true, y_pred) * mask
    return tf.reduce_sum(loss) / tf.reduce_sum(mask)


def masked_accuracy(y_true, y_pred):
    """Token accuracy that ignores padding positions."""
    y_pred_ids = tf.argmax(y_pred, axis=-1)
    y_true = tf.cast(y_true, y_pred_ids.dtype)
    matches = tf.cast(y_true == y_pred_ids, tf.float32)
    mask = tf.cast(y_true != 0, tf.float32)
    return tf.reduce_sum(matches * mask) / tf.reduce_sum(mask)
